package com.dialogs;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

import com.dialogs.ds.Student;

public class JfaceTitleDialog1 extends TitleAreaDialog {
	
	protected Object result;
	protected Shell shell;
	private Text namTextBox;
	private Text ageTextBox;
	private Table table;
	private List<Student> studentList = new ArrayList<>();
	private TableViewer studentDataTableViewer;
	

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public JfaceTitleDialog1(Shell parentShell) {
		super(parentShell);
	}
	
	@Override
	protected boolean isResizable() {
		return true;
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite area = (Composite) super.createDialogArea(parent);
		Composite mainComposite = new Composite(area, SWT.NONE);
		mainComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
		mainComposite.setLayout(new GridLayout(1, false));
		mainComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		Composite headerComposite = new Composite(mainComposite, SWT.NONE);
		headerComposite.setLayout(new GridLayout(1, false));
		GridData gd_headerComposite = new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1);
		gd_headerComposite.heightHint = 38;
		headerComposite.setLayoutData(gd_headerComposite);
		
		Label lblStudentData = new Label(headerComposite, SWT.NONE);
		lblStudentData.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, true, 1, 1));
		lblStudentData.setText("STUDENT DATA");
		
		Composite dataComposite = new Composite(mainComposite, SWT.NONE);
		dataComposite.setLayout(new GridLayout(2, false));
		dataComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		
		Composite viewDataComposite = new Composite(mainComposite, SWT.NONE);
		viewDataComposite.setLayout(new GridLayout(1, false));
		viewDataComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		createTableViewer(viewDataComposite);
		
		
		
		Label lblStudentName = new Label(dataComposite, SWT.NONE);
		lblStudentName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblStudentName.setText("Student Name");
		
		namTextBox = new Text(dataComposite, SWT.BORDER);
		namTextBox.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		namTextBox.addModifyListener(new ModifyListener() {
			
			@Override
			public void modifyText(ModifyEvent e) {
				System.out.println("Name:"+namTextBox.getText());
			}
		});
		
		Label lblAge = new Label(dataComposite, SWT.NONE);
		lblAge.setText("Age");
		
		ageTextBox = new Text(dataComposite, SWT.BORDER);
		ageTextBox.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(dataComposite, SWT.NONE);
		
		Button btnSubmit = new Button(dataComposite, SWT.NONE);
		btnSubmit.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		btnSubmit.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try{
				Student student = new Student(namTextBox.getText(), Integer.parseInt(ageTextBox.getText()));
				studentList.add(student);
				System.out.println(studentList);
				studentDataTableViewer.refresh();
				}catch (ArithmeticException exception) {
					exception.printStackTrace();
					namTextBox.setText("");
					ageTextBox.setText("");
				}
			}
		});
		btnSubmit.setText("Submit");

		
		
		return area;
	}

	private void createTableViewer(Composite viewDataComposite) {
		studentDataTableViewer = new TableViewer(viewDataComposite, SWT.BORDER | SWT.FULL_SELECTION);
		table = studentDataTableViewer.getTable();
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		TableViewerColumn studentNameColumnViewer = new TableViewerColumn(studentDataTableViewer, SWT.NONE);
		TableColumn tblclmnStudentName = studentNameColumnViewer.getColumn();
		tblclmnStudentName.setWidth(219);
		tblclmnStudentName.setText("Student Name");
		studentNameColumnViewer.setLabelProvider(new ColumnLabelProvider(){
			
			@Override
			public String getText(Object element) {
				Student student = (Student) element;
				return student.getName();
			}
		});
		
		
		TableViewerColumn studentAgeColumnViewer = new TableViewerColumn(studentDataTableViewer, SWT.NONE);
		TableColumn tblclmnAge = studentAgeColumnViewer.getColumn();
		tblclmnAge.setWidth(100);
		tblclmnAge.setText("Age");
		studentAgeColumnViewer.setLabelProvider(new ColumnLabelProvider(){
			
			@Override
			public String getText(Object element) {
				Student student = (Student) element;
				return String.valueOf(student.getAge());
			}
		});
		
		
		studentDataTableViewer.setContentProvider(new ArrayContentProvider());
		studentDataTableViewer.setInput(studentList);
		
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, "Finish", true);
		createButton(parent, IDialogConstants.CANCEL_ID, "Exit", false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(501, 447);
	}
	
	@Override
	protected void okPressed() {
		super.okPressed();
		
	}
	
	
	@Override
	protected void cancelPressed() {
		// TODO Auto-generated method stub
		super.cancelPressed();
	}

}
